#include <stdlib.h>

char *
getenv (const char *name)
{
  return NULL;
}
